package com.example.Echo;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class News extends AppCompatActivity  {
    private WebView News;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news);
        News = (WebView) findViewById(R.id.webview);
        News.setWebViewClient(new WebViewClient());
        News.loadUrl("https://www.ghanaweb.com/GhanaHomePage/business/");
        WebSettings webSettings = News.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }
    @Override
    public void onBackPressed() {
        if (News.canGoBack()) {
            News.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
